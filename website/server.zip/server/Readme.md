Build Server With CRUD rest API with typescript + Express.js + Sequeslize +  Sqlite3 (Not SQLScript)

init server => Build a server application

[x] set up typescript for dev
[x] basic express server with typescript
[x] setup db
[x] create model 


[ ] create Model InnovationIdea
[ ] Create InnovationIdeaController 
    -> [ ] GetAllIdea
    -> [ ] CreateIdea
    -> [ ] Update(edit) Idea
    -> [ ] DeleteIdea
[ ] Routers InnovationIdeaRouters
[ ] try to using API throuth PostMan